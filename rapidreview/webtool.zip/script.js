function addRowToTableBody(table, cellData) {
  const tableBody = table.getElementsByTagName('tbody').item(0);
  if (tableBody) {
    const row = document.createElement('tr');
    for (let i = 0, iLength = cellData.length; i < iLength; i += 1) {
      const cell = document.createElement('td');
      cell.innerHTML = (cellData[i]);
      row.appendChild(cell);
    }
    // const cell = document.createElement('td');
    // const uid = fileJSON.cord_uid;
    // const cellContent = document.createTextNode(uid);
    // cell.appendChild(cellContent);
    // row.appendChild(cell);

    // const cell = document.createElement('td');
    // const sent = fileJSON.text;
    // const cellContent = document.createTextNode(sent);
    // cell.appendChild(cellContent);
    // row.appendChild(cell);

    tableBody.appendChild(row);
  }
}

function parseData(fileJSON) {
    const table = document.getElementById('table');
    const denotations = fileJSON.denotations || [];
    const text = fileJSON.text
    for (let i =0, iLength = denotations.length; i < iLength; i += 1) {
        const span = denotations[i].span;
        const word = text.substring(span.begin, span.end)
        const startSen = text.substring(0, span.begin).split(".").pop();
        const endSen = text.substring(span.end, -1).split(".").shift();
        const fullSen = `${startSen}<span class = "highlight">${word}</span> ${endSen}`
        const cellData = [fileJSON.cord_uid, fullSen,
            denotations[i].id, word, denotations[i].obj];
        addRowToTableBody(table, cellData);
    }
}

function handleFiles() {
  const fileList = this.files;
  if (fileList[0]) {
    const reader = new FileReader();
    reader.readAsText(fileList[0], "UTF-8");
    reader.onload = function (event) {
      const fileContents = event.target.result;
      const fileJSON = JSON.parse(fileContents);
      parseData(fileJSON);
    }
    reader.onerror = function (evt) {
      console.error("error reading file");
    }
  }
}

const inputButton = document.getElementById('inputt');
inputButton.addEventListener("change", handleFiles, false);